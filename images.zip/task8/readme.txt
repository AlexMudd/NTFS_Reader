fold1.img:
    fold1/FORTASK1 (md e7e0)

fold2.img:
    FORTASK (md e7e0)
    fold1/FORTASK1 (md e7e0)
    fold1/fold2/FORTASK2 (md e7e0)

nonres.img:
    FORTASK (md 24a7)
